/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : Initial program to call the matrix program and create a matrix
           of data, with will be directed
*/

package dijkstrasalgorithm;


public class Vertex {
    int from;
    int to;
    int weight;
    
    Vertex(int from, int to, int weight) {
        this.from   = from;
        this.to     = to;
        this.weight = weight;
    }
}
