/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : Initial program to call the matrix program and create a matrix
           of data, with will be directed
*/

package dijkstrasalgorithm;

public class tableVertex {
    int current;
    boolean visited;
    int previous;
    int totalWeight;
    
    tableVertex(int current, boolean visited, int previous, int totalWeight) {
        this.current     = current;
        this.visited     = visited;
        this.previous    = previous;
        this.totalWeight = totalWeight;
    }
}
