/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : Initial program to call the matrix program and create a matrix
           of data, with will be directed
*/

package dijkstrasalgorithm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DijkstrasAlgorithm {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        // variables for our run
        boolean firstRun = true;
        String filein;

        // keep on going till user wants to exit out
        do {

            // call a function to get in our file name (and show some info)
            filein = getFileName(firstRun);
            firstRun = false;

            // check if we need to proceed or not
            if (filein.equals("exit") || filein.equals("quit"))
                System.out.println("\n\nExiting out of program\n\n");
            else {
                processInputFile(filein);
            }
        } while (!(filein.equals("exit")) && (!filein.equals("quit")));
    }
    
    // get in the file to be processed
    private static String getFileName(boolean firstRun) {
        
        boolean invalidInput = true;
        String filein;
        
        // first run, show some info
        if (firstRun) {
            System.out.println("Program to try and use Dijkstras Algorithm to");
            System.out.println("solve the 'Shortest Path' problem");
        }
        else {
            System.out.println("\n\n\n\n\n");
        }
        
        do {

            // get in the file to be processed
            System.out.println("Input file name to proceed (exit/quit to exit)");
            System.out.print  ("File: ");

            Scanner s = new Scanner(System.in);
            filein = s.next();

            // is the user getting out or not?
            if (filein.equals("exit") || filein.equals("quit"))
                invalidInput = false;
            
            // check if the file is there or not
            else {
                try {
                    File f  = new File(filein);
                    FileReader fr = new FileReader(f);
                    BufferedReader br = new BufferedReader(fr);
                    invalidInput = false;
                    br.close();
                    fr.close();
                } 
                catch (IOException ioe) {
                    System.out.println("\n\nSorry, file " + filein + " could not be found" );
                    System.out.println("Make sure the file is in the same folder as the program");
                    System.out.println("or that the path is correctly specified");
                    System.out.println("System message: " + ioe);
                    System.out.println("\n\n\n\n\n");
                }
            }
            
        // while the input is not right, keep on looping around
        } while (invalidInput);
        
        
        // send back the file name
        return filein;
    }

    private static void processInputFile(String filein) throws IOException {
        
        // error control flag
        boolean errorFound = false;

        // open our file (we already know it is there)
        FileProcessing ourFile = null;
        try {
            ourFile = new FileProcessing(filein);
        } catch (IOException ex) {
            System.out.println("Somebody deleted the file : " + ex);
        }
        
        // get our first parmeter - type of graph
        int fileInt = ourFile.readFileForValue();

        // have we reached the end of the file
        if (fileInt == -1) {
            System.out.println("No Arc Type found - eof encountered");
            errorFound = true;
        }
         
        // if we have an ARC, do we have nbr of vertices
        if (!errorFound) {

            // save off type of graph
            char graphType = (char) fileInt;
            System.out.println("Graph type is             : " + graphType);

            // get our second parmeter - nbr of vertex's
            fileInt = ourFile.readFileForValue();

            // have we reached the end of the file
            if (fileInt == -1) {
                System.out.println("Nbr of Vertices not found");
                errorFound = true;
            }

            // we have Arc type and nbr of vertices, now find all vertex'es
            if (!errorFound) {
                loadAllVertices(fileInt, ourFile);
            }
        }
    }
    
    // we have Arc type and nbr of vertices, now find all vertex'es
    public static void loadAllVertices(int fileInt, FileProcessing ourFile) throws IOException {

        // error control flag
        boolean errorFound = false;

        // save off type of graph and find max nbr vertices
        int nbrVertices = fileInt;
        int maxNbrVertices = nbrVertices * nbrVertices - nbrVertices;
        System.out.println("Number of Vertices is     : " + nbrVertices);
        System.out.println("Max Number of Vertices is : " + maxNbrVertices);

        // get ready for loading in our data
        Vertex vertex;
        int i = 0;

        // create our graph
        Graph graph = new Graph(nbrVertices);

        // load in our data (Stream of Arcs or Arc Array)
        do {
            vertex = ourFile.readVertice();
            i++;
            if (vertex.weight == 0 || vertex.weight == -2) {
                i--;
                System.out.println("Cannot process file as we do not have valid inputs");
                System.out.println("Proessed " + i + " out of " + maxNbrVertices + " vertices");
                System.out.println("From: " + vertex.from + ", To: " + vertex.to + ", Weight: " + vertex.weight);
                errorFound = true;
            }
            else {
                if (vertex.weight > 0) {
                    if (!graph.addEdge(vertex.from, vertex.to, vertex.weight)) {
                        System.out.println("\t\tCould not add vertice as it is invalid. (" + vertex.from + ", To: " + vertex.to + ", Weight: " + vertex.weight + ")");
                        errorFound = true;
                    }
                }
            }
        // while
        //      we do not have an error (!errorFound)
        //      and our counter (i) is less than maxNbrVertices (Stream of Arcs)
        //      and vertex.weight != -1 (end of file not reached on Array of arcs
        } while (!errorFound && i < maxNbrVertices && vertex.weight != -1);

        // if all is Ok, then do the following
        if (!errorFound) {
            
            // print out our graph details
            graph.dumpGraph();

            // if all is good, then lets build a path from somewhere (and possibly to somewhere).
            Path path = new Path(graph);
            path.buildPath();
            path.dumpPath();
        }
    }
}
