/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : To create and store nodes (vertices) into an matrix adjancy list and
           provide functions for the user interact with the matrix
*/

package dijkstrasalgorithm;

import java.util.LinkedList;


// main class of the function
public class Graph {
    
    // the size of our graph
    int size;
    
    // linklist for our graph
    LinkedList<Node> vertexList[];
    
    // default construtor
    public Graph(int s) {

        // initialise our data array(s) (grid and nodes)
        if (s>0) {
            size = s;
            vertexList = new LinkedList[size];
            for (int i=0; i<size; i++) {
                vertexList[i]        = new LinkedList<>();
            }
        }
    }
    
    // add in an edge
    public boolean addEdge(int i, int j, int w) {
        boolean added = false;
        if (validPoints(i, j)) {
            if (!isAlreadyAdded (i, j)) {
                i--; j--;
                Node node = new Node(j, w);
                vertexList[i].addLast(node);
                added = true;
            }
        }
        return added;
    }
    
    // does the "to" already exist in the list for "from"
    public boolean isAlreadyAdded(int i, int j) {
        boolean found = false;
        if (validPoints(i, j)) {
            i--; j--;
            for (int x=0; x< vertexList[i].size() && !found; x++) {
                Node check = vertexList[i].get(x);
                if (check.node == j) {
                    found = true;
                }
            }
        }
        return found;
    }

    // number of elements in array
    public int size() {
        return vertexList.length;
    }

    // number of connections
    public int nbrDegrees(int i) {
        int j;
        int degrees = 0;
        
        if (i>0 && i<(size+1)) {
            degrees = vertexList[i-1].size();
        }
        return degrees;
    }

    // who are our neighbours
    public Node[] listNeighbours(int i) {
        int x;

        if (i>0 && i<(size+1)) {
            i--;
        
            x = vertexList[i].size();
            Node listNodes[] = new Node[x];
            for (int j=0; j<vertexList[i].size(); j++) {
                Node node = vertexList[i].get(j);
                node.node++;
                listNodes[j] = node;
                }
            return listNodes;
        }
        else {
            return null;
        }
    }

    // who are our neighbours but without updating node references
    public Node[] listNeighboursNotUpdated(int i) {
        int x;

        if (i>0 && i<(size+1)) {
            i--;
        
            x = vertexList[i].size();
            Node listNodes[] = new Node[x];
            for (int j=0; j<vertexList[i].size(); j++) {
                Node node = vertexList[i].get(j);
                listNodes[j] = node;
                }
            return listNodes;
        }
        else {
            return null;
        }
    }

    // validate our points sent in
    private boolean validPoints(int i, int j) {
        boolean valid = true;

        // are the points good?
        if (i<1 || i>size || j<1 || j>size || i==j) {
            valid = false;
        }
        
        // return back what we know
        return valid;
    }
    
    // print out our graph
    public void dumpGraph() {
        // heading line(s)
        System.out.println("        Linked node(s) & weight(s)");

        // each line of the graph
        for(int i=0; i<size; i++) { 
            System.out.print("row = " + (i+1) + " ");
            for (int j=0; j<vertexList[i].size(); j++) {
                Node node = vertexList[i].get(j);
                System.out.print("{" + (node.node + 1) + ", " + node.weight + "} ");
            }
            System.out.println();
        }
        System.out.println();
    } 
}