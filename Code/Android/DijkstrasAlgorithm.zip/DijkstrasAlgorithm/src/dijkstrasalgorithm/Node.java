/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : Initial program to call the matrix program and create a matrix
           of data, with will be directed
*/

package dijkstrasalgorithm;

public class Node {

    // node properties
    int node;
    int weight;

    Node(int node, int weight) {
        this.node     = node;
        this.weight = weight;
    }
}
