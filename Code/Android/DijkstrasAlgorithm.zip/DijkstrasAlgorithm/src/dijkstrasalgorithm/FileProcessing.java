/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : Initial program to call the matrix program and create a matrix
           of data, with will be directed
*/

package dijkstrasalgorithm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileProcessing {

    // all our file pointers
    File f;                 // file pointer
    FileReader fr;          // file reader pointer
    BufferedReader br;      // buffered reader file pointer

    // type of graph
    char graphType;
    
    // nbr of vertices in graph
    int nbrOfVertices = 0;

    // count of number of vertices read for array processing
    int cntVert = 0;

    // save our row and column
    int row = 1, col = 0;

    // open our file if possible
    FileProcessing(String fileName) throws IOException {
        
        boolean response = false;

        // try and open the file
        try {
            f  = new File(fileName);          //Creation of File Descriptor for input file
            fr = new FileReader(f);           //Creation of File Reader object
            br = new BufferedReader(fr);      //Creation of BufferedReader object
            response = true;
        } 
        catch (IOException ioe) {
            System.out.println("Exception while processing file " + ioe);
        }
    }
    
    // read in our Vertex (From, To and Weight) or Array (row, col, weight)
    public Vertex readVertice() throws IOException {
        
        // character to read in and flag if char is valid or not
        Vertex vertex = new Vertex(0, 0, 0);
        boolean validVertex = false;

        // storage of character from the file;
        int c;
        
        // are we procesing stream of arcs
        if (graphType == 's' || graphType == 'S') {
        
            // get from verted
            c = readFileForValue();
            if (c != -1) {
                vertex.from = c;

                // get to vertex
                c = readFileForValue();
                if (c != -1) {
                    vertex.to = c;

                    // get weight between vertices
                    c = readFileForValue();
                    if (c != -1) {
                        vertex.weight = c;
                        validVertex = true;
                    }
                    else {
                        vertex.weight = -1;
                    }
                }
                else {
                    vertex.weight = -1;
                }
            }
            else {
                vertex.weight = -1;
            }
        }
        
        // otherwise we have an array of weights
        else {
            vertex.weight = readFileForArray();
            if (vertex.weight > 0) {
                vertex.from = row;
                vertex.to   = col;
                validVertex = true;
            }
        }
        
        // return vertex (row and col == 0 with negative weight on error)
        return vertex;
    }

    // read a character from our file and return vertex - Arc weight array
    private int readFileForArray() throws IOException {
        
        // out weight for building
        int weight;
        
        // if weight is valid, (<0 not valid), then update rows / cols
        do {
            
            // get in our bit of data
            weight = readFileForValue();
            cntVert++;
            
            // check if we have valid data or not
            if (weight >= 0) {
    
                // figure out our row and column numbers
                col++;
                if (col > nbrOfVertices) {
                    row++;
                    col = 1;
                }
                
                // are we on the diagonal
                if (row == col && weight != 0) {
                    weight = -2;
                }
                
                // have we gone over - if so, set eof to terminate inputs
                if (row > nbrOfVertices) {
                    weight = -1;
                }
            }
            
        // while we have no valid value (-1 is end of file and -2 is error)
        } while (weight == 0);
        
        // return back weight
        return weight;
    }

    // read a character(s) from our file (numbers after one another are processed)
    public int readFileForValue() throws IOException {
        
        // character to read in and flag if char is valid or not
        int c, val = 0;
        boolean validChar = false;

        // Read char by Char
        do {
            c = br.read(); 
            
            // is this a comment line (start with a '/' till end of line)
            if ( ((char) c) == '/' ) {
                do {
                    c = br.read();
                } while (((char) c) != '/' && c != -1);
            }
            
            // do we have an initial number, if so, are there more...
            if (c > 47 && c < 58) {
                validChar = true;
                do {
                    val = val * 10 + Character.getNumericValue(c);
                    c = br.read();
                } while (c > 47 && c < 58);
                c = val;
                
                // save off number of vertices (first number found)
                if (nbrOfVertices == 0)
                    nbrOfVertices = c;
            }
            
            // do we have a 'A/a' 
            if ( !validChar && (c == 65 || c ==  97) ) {
                graphType = (char) c;
                validChar = true;
            }
            
            // do we have a 'S/s' 
            if ( !validChar && (c == 83 || c == 115) ) {
                graphType = (char) c;
                validChar = true;
            }
            
        // while we do not have a valid character (0-9, a, A, s, S -> valid) and not eof
        } while (!validChar && c != -1); 
        
        // return character int value we found
        return c;
    }

    // close the file we are reading
    public void closeFile() throws IOException {

        // close our buffered reader
        try {
            if (br != null) {
                br.close();
            }
        } 
        catch (IOException ioe) {
            System.out.println("Error while closing Buffered Reader: " + ioe);
        }
        
        // close our file reader
        try {
            if (fr != null) {
                fr.close();
            }
        } 
        catch (IOException ioe) {
            System.out.println("Error while closing File Reader: " + ioe);
        }
    }
}
