/*
Author   : Christopher J. Costelloe (K00233369)
Date     : 19-Sept-2019
Function : Initial program to call the matrix program and create a matrix
           of data, with will be directed
*/

package dijkstrasalgorithm;

import java.util.Scanner;
import java.util.Stack;

public class Path {
    
    // local variables for processing
    int strVertex;
    int dstVertex;
    Graph graph;
    tableVertex finalTable[];
    
    // receive in our basic graph and use this to buld the path
    public Path(Graph graph) {
        this.graph = graph;
    
    // setup array with correct size and initialise it.
        finalTable = new tableVertex[graph.size()];
        for(int i=0; i < graph.size(); i++) {
            tableVertex tv = new tableVertex((i + 1), false, -1, 999999);
            finalTable[i] = tv;
        }
    }
    
    // build the path(s) form the choosen vertex
    public void buildPath() {

        // get in our source starting location
        System.out.println("Input a starting / destination vertex betwen 1 and " + graph.size() );
        boolean notValid = true;
        do {
            System.out.print  ("  Starting Vertex / Node: ");
            Scanner s = new Scanner(System.in);
            String startVertex = s.next();
            strVertex = Integer.parseInt(startVertex);
            if (strVertex  >= 1 && strVertex <= graph.size() && graph.nbrDegrees(strVertex) > 0) {
                notValid = false;
            }
            else { 
                if (graph.nbrDegrees(strVertex) > 0)
                    System.out.println("  Invalid Input - try again");
                else {
                    System.out.println("  Vertex selected is not connected to any other vertexes - cannot generate tree or path!");
                }
            }
        } while(notValid);
     
        // get in our destination location
        notValid = true;
        do {
            System.out.print  ("  Destination Vertex / Node (0 for no destination -> build tree): ");
            Scanner s = new Scanner(System.in);
            String destVertex = s.next();
            dstVertex = Integer.parseInt(destVertex);
            if (dstVertex  >= 0 && dstVertex <= graph.size()) {
                notValid = false;
            }
            else { 
                System.out.println("  Invalid Input - try again");
            }
        } while(notValid);
        
        // we have a starting location, so now build the tree (if destination is 0 else path to destination)
        
        // for each and every element in our graph
        boolean somethingToProcess = true;
        int checkWeight = 999999;
        int checkVertex = -1;

        // setup our starting point for the path
        int processVertex = strVertex - 1;
        finalTable[processVertex].visited     = true;
        finalTable[processVertex].totalWeight = 0;
        finalTable[processVertex].previous    = -1;
        int totalWeight = 0;
                    
        // lets process for the selected node (this changes inside the loop)
        do {
        
            // if we have something there for processing
            if (graph.nbrDegrees(processVertex + 1) > 0) {

                // get the list of neighbours for the slected node
                Node node[] = graph.listNeighboursNotUpdated(processVertex + 1);
                
                // possibly update the table for the nodes
                for (int i=0; i < node.length; i++) {
                    
                    // weight for the node of where we are to where we are going
                    int weightFromHereToThere = finalTable[processVertex].totalWeight + node[i].weight;
                    
                    // weight of node to where we are going
                    int weightThere = finalTable[node[i].node].totalWeight;
                    
                    // do we update or not ?
                    if (weightFromHereToThere < weightThere) {
                        finalTable[node[i].node].totalWeight = weightFromHereToThere;
                        finalTable[node[i].node].previous    = processVertex;
                    }
                }
            } // end of if (something there)
            
            // set vertex as processed
            finalTable[processVertex].visited = true;
            
            // search for next shortest distance node
            checkWeight = 999999;
            checkVertex = processVertex;
            for (int i=0; i < graph.size(); i++) {
                if (!finalTable[i].visited) {
                    if (finalTable[i].totalWeight < checkWeight) {
                        checkWeight = finalTable[i].totalWeight;
                        checkVertex = i;
                    }
                }
            }
            
            // if checkVertex and process Vertex are different, process node else terminate loop
            if (checkVertex != processVertex) {
                totalWeight = finalTable[checkVertex].totalWeight;
                processVertex = checkVertex;
            }
            else {
                somethingToProcess = false;
            }
        
        // while we have something to process (note we may not process all the array)
        } while (somethingToProcess); // end of while loop
    }
    
    // dump the table of paths and the non-connected vertices.
    public void dumpPath() {
        
        // if no destination, then just dump what we have
        if (dstVertex == 0) {

            // just dump out our table for the moment
            for (int i=0; i < graph.size(); i++) {
                System.out.println("to Node " + (i+1) + " from node " + (finalTable[i].previous + 1) + " for a weight of " + finalTable[i].totalWeight);
            }
        }
        else {
            
            // variables that we need
            boolean loadStack = true;
            Stack<tableVertex> stack = new Stack();
            dstVertex--;
            int stackCount = 0;
            int stepDistance = 0;
            
            // take what we have and put it onto a stack 
            do {
                stack.push(finalTable[dstVertex]);
                stackCount++;
                dstVertex = finalTable[dstVertex].previous;
                if (dstVertex == -1) {
                    loadStack = false;
                }
            } while (loadStack);
            
            // now pop the stack and show the user what we have
            do {
                finalTable[0] = stack.pop();
                stackCount--;
                if (finalTable[0].previous == -1) {
                    System.out.println("\n\nPATH: Starting from " + finalTable[0].current);
                }
                else {
                    System.out.println("\t\tthen onto " + finalTable[0].current + " for a distance of " + 
                            (finalTable[0].totalWeight - stepDistance) + 
                            " (Total Distance Travelled so far, is " + finalTable[0].totalWeight + ")");
                    stepDistance = finalTable[0].totalWeight;
                }
            } while(stackCount > 0);
        }
    }
}
