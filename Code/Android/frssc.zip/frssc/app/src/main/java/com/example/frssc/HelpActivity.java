package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        // setup our debug tag in case we need it in the logs
        String DEBUG_TAG = "FRSSC:Help";

        // Read raw file into string and populate the TextView
        InputStream iFile = getResources().openRawResource(R.raw.help);
        try {
            TextView helpText = (TextView) findViewById(R.id.textHelp);
            String strFile = inputStreamToString(iFile);
            helpText.setText(strFile);
        }
        catch (Exception e) {
            Log.e(DEBUG_TAG, "InputStreamToString failure", e);
        }
    }

    public String inputStreamToString(InputStream is) throws IOException {

        StringBuffer sBuffer = new StringBuffer();
        BufferedReader dataIO = new BufferedReader(new InputStreamReader(is));
        String strLine = null;

        // read in all the data from the help file
        while ((strLine = dataIO.readLine()) != null) {
            sBuffer.append(strLine + "\n");
        }

        // close the files
        dataIO.close();
        is.close();

        // return back the created string
        return sBuffer.toString();
    }
}
