package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DelPostActivity extends AppCompatActivity implements View.OnClickListener {

    // shared preferences
    SharedPreferences mFRSSCsettings;
    public static final String FRSSC_PREFERENCES = "FRSSCprefs";
    public static final String FRSSC_USERID   = "userid";
    public static final String FRSSC_NICKNAME = "nickname";

    // variables
    Button btnDeletePost, btnDelPrev, btnDelNext;
    TextView viewDelPostId, viewDelUser, viewDelDate, viewDelTime, viewDelPost;
    SQLiteDatabase db;
    String userId, nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_del_post);

        // references to resources
        btnDeletePost = findViewById(R.id.btnDeletePost);
        btnDelPrev    = findViewById(R.id.btnDelPrev);
        btnDelNext    = findViewById(R.id.btnDelNext);

        viewDelPostId = findViewById(R.id.txtDelPostId);
        viewDelUser   = findViewById(R.id.txtDelUserId);
        viewDelDate   = findViewById(R.id.txtDelDate);
        viewDelTime   = findViewById(R.id.txtDelTime);
        viewDelPost   = findViewById(R.id.txtDelPost);

        // click listeners
        btnDeletePost.setOnClickListener(this);
        btnDelPrev.setOnClickListener(this);
        btnDelNext.setOnClickListener(this);

        // create our database if needed
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);

        // pull details from the shared preferences area
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            userId = mFRSSCsettings.getString(FRSSC_USERID, "");
            nickname = mFRSSCsettings.getString(FRSSC_NICKNAME, "");
        }
        viewDelUser.setText(nickname);

        // get the first record from the database
        Cursor c = db.rawQuery("Select * from posts where userid='" +
                userId + "' order by postid DESC ",null);
        if(c.moveToFirst())
        {
            viewDelPostId.setText(c.getString(0));
            viewDelUser.setText(nickname);
            viewDelDate.setText(c.getString(2));
            viewDelTime.setText(c.getString(3));
            viewDelPost.setText(c.getString(4));
        }
        else
        {
            viewDelPostId.setText("");
            viewDelDate.setText("");
            viewDelTime.setText("");
            viewDelPost.setText("No Posts to View");
            showMessage("Issue", "No posts exist for this user");
        }
    }

    // handle the button the user has clicked on
    public void onClick(View view)
    {
        // get the postid, convert to number and get previous record
        String PostId = viewDelPostId.getText().toString().trim();
        int PostIdNum = 0;
        try {
            PostIdNum = Integer.parseInt(PostId);
        }
        catch(NumberFormatException nfe) {
            showMessage("Error", "Cannot convert post id to number");
            return;
        }

        // Previous post on the list
        if(view == btnDelPrev)
        {
            // get the previous record
            Cursor c = db.rawQuery("Select * from posts where userid ='" + userId +
                    "' and postid < '" + PostIdNum + "' order by postid DESC",null);

            if(c.moveToFirst())
            {
                viewDelPostId.setText(c.getString(0));
                viewDelUser.setText(nickname);
                viewDelDate.setText(c.getString(2));
                viewDelTime.setText(c.getString(3));
                viewDelPost.setText(c.getString(4));
            }
            else
            {
                showMessage("Issue","Already reviewing the first post");
            }
        }

        // Next post on the list
        if(view == btnDelNext)
        {
            // get the next record
            Cursor c = db.rawQuery("Select * from posts where userid ='" + userId +
                    "' and postid > '" + PostIdNum + "'",null);

            if(c.moveToFirst())
            {
                viewDelPostId.setText(c.getString(0));
                viewDelUser.setText(nickname);
                viewDelDate.setText(c.getString(2));
                viewDelTime.setText(c.getString(3));
                viewDelPost.setText(c.getString(4));
            }
            else
            {
                showMessage("Issue","Already viewing the last post");
            }
        }

        // Delete the selected post
        if(view == btnDeletePost)
        {
            // delete the post we are on
            db.execSQL("Delete from posts where postid='" + PostIdNum + "'");
            showMessage("Success", "Post has been Deleted");

            // get the next record, if there is one
            Cursor c = db.rawQuery("Select * from posts where userid ='" + userId +
                    "' and postid > '" + PostIdNum + "'",null);

            // if we got a record, then show it up
            if(c.moveToFirst()) {
                viewDelPostId.setText(c.getString(0));
                viewDelUser.setText(nickname);
                viewDelDate.setText(c.getString(2));
                viewDelTime.setText(c.getString(3));
                viewDelPost.setText(c.getString(4));
            }

            // otherwise check if there is a previous record
            else {
                c = db.rawQuery("Select * from posts where userid ='" + userId +
                        "' and postid < '" + PostIdNum + "' order by postid DESC",null);

                // if we got a record, then show it up
                if(c.moveToFirst()) {
                    viewDelPostId.setText(c.getString(0));
                    viewDelUser.setText(nickname);
                    viewDelDate.setText(c.getString(2));
                    viewDelTime.setText(c.getString(3));
                    viewDelPost.setText(c.getString(4));
                }
                else {
                    viewDelPostId.setText("");
                    viewDelUser.setText("");
                    viewDelDate.setText("");
                    viewDelTime.setText("");
                    viewDelPost.setText("");
                    showMessage("Issue", "No more posts to view for this user");
                }
            }
        }
    }

    public void showMessage (String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
