package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // variables
    Button btnViewPosts, btnRegister, btnLogin, btnAbout, btnHelp;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // references to resources
        btnViewPosts = findViewById(R.id.btnViewPosts);
        btnRegister  = findViewById(R.id.bthRegister);
        btnLogin     = findViewById(R.id.btnLogin);
        btnHelp      = findViewById(R.id.btnHelp);
        btnAbout     = findViewById(R.id.btnAbout);

        // click listeners
        btnViewPosts.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
        btnLogin.setOnClickListener(this);
        btnHelp.setOnClickListener(this);
        btnAbout.setOnClickListener(this);

        // create our database if needed
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS " +
                "register(" +
                "userid VARCHAR ," +
                "password VARCHAR, " +
                "nickname VARCHAR);");

        db.execSQL("CREATE TABLE IF NOT EXISTS " +
                "posts(" +
                "postid INTEGER PRIMARY KEY AUTOINCREMENT," +
                "userid VARCHAR, " +
                "datePost VARCHAR, " +
                "timePost VARCHAR, " +
                "postText VARCHAR);");
    }

    // handle the button the user has clicked on
    public void onClick(View view)
    {
        // view all posts on the database
        if(view == btnViewPosts)
        {
            Intent intent = new Intent(this, ViewPostsActivity.class);
            startActivity(intent);
        }

        // register a new user
        if(view == btnRegister)
        {
            Intent intent = new Intent(this, RegisterActivity.class);
            startActivity(intent);
        }

        // allow a registered user to login
        if(view == btnLogin)
        {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        // Help Screen
        if(view == btnHelp)
        {
            Intent intent = new Intent(this, HelpActivity.class);
            startActivity(intent);
        }

        // About Screen
        if(view == btnAbout)
        {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
        }
    }
}
