package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UpdateThePostActivity extends AppCompatActivity implements View.OnClickListener {

    // shared preferences
    SharedPreferences mFRSSCsettings;
    public static final String FRSSC_PREFERENCES = "FRSSCprefs";
    public static final String FRSSC_USERID   = "userid";
    public static final String FRSSC_NICKNAME = "nickname";

    // variables
    Button btnUpdPostInput;
    TextView txtUpdPostId, txtUpdUserId, txtUpdDate, txtUpdTime;
    EditText edtUpdPost;
    SQLiteDatabase db;
    String PostId = "", datePost = "", timePost = "";
    int PostIdNum = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_the_post);

        // retrieved passed data and convert to number
        Intent intent = getIntent();
        PostId = intent.getStringExtra("PostID");
        try {
            PostIdNum = Integer.parseInt(PostId);
        }
        catch(NumberFormatException nfe) {
        }

        // references to resources
        btnUpdPostInput = findViewById(R.id.btnUpdPostInput);

        txtUpdPostId = findViewById(R.id.txtUpdPostId);
        txtUpdUserId = findViewById(R.id.txtUpdUserId);
        txtUpdDate   = findViewById(R.id.txtUpdDate);
        txtUpdTime   = findViewById(R.id.txtUpdTime);
        edtUpdPost   = findViewById(R.id.edtUpdPost);

        // click listeners
        btnUpdPostInput.setOnClickListener(this);

        // create our database if needed
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);

        // pull details from the shared preferences area
        String userId = "", userNickName = "";
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            userNickName = mFRSSCsettings.getString(FRSSC_NICKNAME, "");
        }
        txtUpdUserId.setText(userNickName);

        // get the record from the database
        Cursor c = db.rawQuery("Select * from posts where postid='" +
                PostIdNum + "'",null);
        if(c.moveToFirst())
        {
            txtUpdPostId.setText(c.getString(0));
            txtUpdUserId.setText(userNickName);
            txtUpdDate.setText(c.getString(2));
            txtUpdTime.setText(c.getString(3));
            edtUpdPost.setText(c.getString(4));
        }
        else
        {
            txtUpdPostId.setText("");
            txtUpdUserId.setText("");
            txtUpdDate.setText("");
            txtUpdTime.setText("");
            edtUpdPost.setText("");
            showMessage("Issue", "No posts exist for this user");
        }

    }

    // handle the button the user has clicked on
    public void onClick(View view) {
        // pull details from the shared preferences area
        String userId = "", userNickName = "";
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            userId = mFRSSCsettings.getString(FRSSC_USERID, "");
            userNickName = mFRSSCsettings.getString(FRSSC_NICKNAME, "");
        }
        txtUpdUserId.setText(userId);

        // get the postid, convert to number and get previous record
        String PostId = txtUpdPostId.getText().toString().trim();
        int PostIdNum = 0;
        try {
            PostIdNum = Integer.parseInt(PostId);
        } catch (NumberFormatException nfe) {
            showMessage("Error", "Cannot convert post id to number");
            return;
        }

        // Button to update the record
        if (view == btnUpdPostInput) {
            // get the record to be updated - just making sure it is there
            Cursor c = db.rawQuery("Select * from posts where postid = '"
                    + PostIdNum + "'", null);

            // set the date and time for the post
            datePost = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
            timePost = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

            // update the record if it was found
            if (c.moveToFirst()) {
                db.execSQL("update posts set" +
                        " postText='" + edtUpdPost.getText() +
                        "', datePost='" + datePost +
                        "', timePost='" + timePost +
                        "' where postid ='" + PostIdNum + "'");
                showMessage("Info", "Post has been updated.");
            }
        }
    }

    // This method will be invoked when user click android device Back menu at bottom.
    @Override
    public void onBackPressed() {
        // get the record to be updated - just making sure it is there
        Cursor c = db.rawQuery("Select * from posts where postid = '"
                + PostIdNum + "'", null);

        // set the date and time for the post
        datePost = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        timePost = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        // update the record if it was found
        if (c.moveToFirst()) {
            db.execSQL("update posts set" +
                    " postText='" + edtUpdPost.getText() +
                    "', datePost='" + datePost +
                    "', timePost='" + timePost +
                    "' where postid ='" + PostIdNum + "'");
        }

        Intent intent = new Intent();
        intent.putExtra("PostID_return", PostId);
        setResult(RESULT_OK, intent);
        finish();
    }

    public void showMessage (String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
