package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LMenuActivity extends AppCompatActivity implements View.OnClickListener {

    // shared preferences
    SharedPreferences mFRSSCsettings;
    public static final String FRSSC_PREFERENCES = "FRSSCprefs";
    public static final String FRSSC_USERID   = "userid";
    public static final String FRSSC_NICKNAME = "nickname";

    // variables
    Button btnAddPost, btnUpdPost, btnDelPost, btnDelUser, btnLogout;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lmenu);

        // references to resources
        btnAddPost = findViewById(R.id.btnAddPost);
        btnUpdPost = findViewById(R.id.btnUpdPost);
        btnDelPost = findViewById(R.id.btnDelPost);
        btnDelUser = findViewById(R.id.btnDelUser);
        btnLogout  = findViewById(R.id.btnLogout);

        // click listeners
        btnAddPost.setOnClickListener(this);
        btnUpdPost.setOnClickListener(this);
        btnDelPost.setOnClickListener(this);
        btnDelUser.setOnClickListener(this);
        btnLogout.setOnClickListener(this);
    }

    // handle the button the user has clicked on
    public void onClick(View view)
    {
        // view all posts on the database
        if(view == btnAddPost)
        {
            Intent intent = new Intent(this, AddPostActivity.class);
            startActivity(intent);
        }

        // register a new user
        if(view == btnUpdPost)
        {
            Intent intent = new Intent(this, UpdPostActivity.class);
            startActivity(intent);
        }

        // allow a registered user to login
        if(view == btnDelPost)
        {
            Intent intent = new Intent(this, DelPostActivity.class);
            startActivity(intent);
        }

        // Help Screen
        if(view == btnDelUser)
        {
            Intent intent = new Intent(this, DelUserActivity.class);
            startActivity(intent);
        }

        // About Screen
        if(view == btnLogout)
        {
            // clear out the shared preferences
            mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = mFRSSCsettings.edit();
            editor.clear();
            editor.commit();

            // start off the main menu activity (should somehow destroy this session but not sure now).
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }
}
