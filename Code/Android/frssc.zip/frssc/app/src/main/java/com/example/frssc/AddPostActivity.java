package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddPostActivity extends AppCompatActivity implements View.OnClickListener {
    // shared preferences
    SharedPreferences mFRSSCsettings;
    public static final String FRSSC_PREFERENCES = "FRSSCprefs";
    public static final String FRSSC_USERID   = "userid";

    // variables and database connection
    Button btnAdd;
    EditText edtPost;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);

        // reference edit fields
        edtPost = findViewById(R.id.edtPost);

        // setup our add button
        btnAdd      = findViewById(R.id.btnAddPostInput);
        btnAdd.setOnClickListener(this);

        // setup our database connection
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);
    }

    public void onClick(View view) {

        // check all data is entered or not
        if (edtPost.getText().toString().trim().length()==0) {
            showMessage("Error","Please Input a Post");
            return;
        }

        // retrieve the shared settings so that we can populate the userid with the correct id
        String userid="Test";
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            userid = mFRSSCsettings.getString(FRSSC_USERID, "");
        }

        // set the date and time for the post
        String datePost = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String timePost = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        // add a dummy record into our database
        db.execSQL("INSERT INTO posts (userid, datePost, timePost, postText) VALUES('"+
                userid+"','"+
                datePost+"','"+
                timePost+"','"+
                edtPost.getText().toString().trim()+"');");

        showMessage("Success","Post Added");

        // reset our input fields
        edtPost.setText("");
        edtPost.requestFocus();

        // stay on the screen
        return;
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
