package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    // shared preferences
    SharedPreferences mFRSSCsettings;
    public static final String FRSSC_PREFERENCES = "FRSSCprefs";
    public static final String FRSSC_USERID   = "userid";
    public static final String FRSSC_NICKNAME = "nickname";

    // variables and database connection
    Button btnLoginUser;
    EditText edtUserId, edtPassword;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // reference edit fields and buttons
        edtUserId = findViewById(R.id.edtUserId);
        edtPassword = findViewById(R.id.edtPassWord);
        btnLoginUser = findViewById(R.id.btnLoginUser);
        btnLoginUser.setOnClickListener(this);

        edtUserId.setText("");
        edtPassword.setText("");

        // setup our database connection
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);

        // see if already logged in - just jump tp login menu
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            Intent intent = new Intent(this, LMenuActivity.class);
            startActivity(intent);
        }
   }

    public void onClick(View view) {

        // check all data is entered or not
        if (edtUserId.getText().toString().trim().length()==0 ||
            edtPassword.getText().toString().trim().length()==0) {
            showMessage("Error","All Fields MUST be filled in");
            return;
        }

        // see if we can find that id in our database or not
        Cursor c = db.rawQuery("SELECT * FROM register WHERE userid ='"
                + edtUserId.getText().toString().trim() + "' and password ='"
                + edtPassword.getText().toString().trim() + "'", null);

        // if we find anything, then the user can be logged in, otherwise we have an issue
        if (c.moveToFirst()) {

            // save off userid and nickname to preferences
            SharedPreferences.Editor editor = mFRSSCsettings.edit();
            editor.putString(FRSSC_USERID, c.getString(0));
            editor.putString(FRSSC_NICKNAME, c.getString(2));
            editor.commit();
            editor.clear();

            // go to the login menu screen
            Intent intent = new Intent(this, LMenuActivity.class);
            startActivity(intent);

            // clear out the input fields
            edtUserId.setText("");
            edtUserId.requestFocus();
            edtPassword.setText("");

            // stay on the screen but exit out of this function now
            return;
        }
        else {
            // if we get here, then our id/password does not exist and we cannot log in
            showMessage("FAILURE", "UserID / Password is invalid");
        }

        // reset our input fields
        edtUserId.setText("");
        edtPassword.setText("");
        edtUserId.requestFocus();

        // stay on the screen
        return;
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}
