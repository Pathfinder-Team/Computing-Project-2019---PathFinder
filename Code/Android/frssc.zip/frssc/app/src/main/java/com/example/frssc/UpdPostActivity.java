package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UpdPostActivity extends AppCompatActivity implements View.OnClickListener {

    // shared preferences
    SharedPreferences mFRSSCsettings;
    public static final String FRSSC_PREFERENCES = "FRSSCprefs";
    public static final String FRSSC_USERID   = "userid";
    public static final String FRSSC_NICKNAME = "nickname";

    // variables
    Button btnUpdatePost, btnUpdPrev, btnUpdNext;
    TextView viewUpdPostId, viewUpdUser, viewUpdDate, viewUpdTime, viewUpdPost;
    SQLiteDatabase db;
    public static final int REQUEST_CODE_1 = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upd_post);

        // references to resources
        btnUpdatePost = findViewById(R.id.btnUpdatePost);
        btnUpdPrev    = findViewById(R.id.btnUpdPrev);
        btnUpdNext    = findViewById(R.id.btnUpdNext);

        viewUpdPostId = findViewById(R.id.txtUpdPostId);
        viewUpdUser   = findViewById(R.id.txtUpdUserId);
        viewUpdDate   = findViewById(R.id.txtUpdDate);
        viewUpdTime   = findViewById(R.id.txtUpdTime);
        viewUpdPost   = findViewById(R.id.txtUpdPost);

        // click listeners
        btnUpdatePost.setOnClickListener(this);
        btnUpdPrev.setOnClickListener(this);
        btnUpdNext.setOnClickListener(this);

        // create our database if needed
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);

        // pull details from the shared preferences area
        String userId = "", userNickName = "";
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            userId       = mFRSSCsettings.getString(FRSSC_USERID, "");
            userNickName = mFRSSCsettings.getString(FRSSC_NICKNAME, "");
        }
        viewUpdUser.setText(userId);

        // get the first record from the database
        Cursor c = db.rawQuery("Select * from posts where userid='" +
                userId + "' order by postid DESC ",null);
        if(c.moveToFirst())
        {
            viewUpdPostId.setText(c.getString(0));
            viewUpdUser.setText(userNickName);
            viewUpdDate.setText(c.getString(2));
            viewUpdTime.setText(c.getString(3));
            viewUpdPost.setText(c.getString(4));
        }
        else
        {
            viewUpdPostId.setText("");
            viewUpdUser.setText("");
            viewUpdDate.setText("");
            viewUpdTime.setText("");
            viewUpdPost.setText("No Posts to View");
            showMessage("Issue", "No posts exist for this user");
        }
    }

    // handle the button the user has clicked on
    public void onClick(View view)
    {
        // pull details from the shared preferences area
        String userId = "", userNickName = "";
        mFRSSCsettings = getSharedPreferences(FRSSC_PREFERENCES, Context.MODE_PRIVATE);
        if (mFRSSCsettings.contains(FRSSC_USERID)) {
            userId       = mFRSSCsettings.getString(FRSSC_USERID, "");
            userNickName = mFRSSCsettings.getString(FRSSC_NICKNAME, "");
        }
        viewUpdUser.setText(userId);

        // get the postid, convert to number and get previous record
        String PostId = viewUpdPostId.getText().toString().trim();
        int PostIdNum = 0;
        try {
            PostIdNum = Integer.parseInt(PostId);
        }
        catch(NumberFormatException nfe) {
            showMessage("Error", "Cannot convert post id to number");
            return;
        }

        // Previous post on the list
        if(view == btnUpdPrev) {
            // get the previous record
            Cursor c = db.rawQuery("Select * from posts where userid ='" + userId +
                    "' and postid < '" + PostIdNum + "' order by postid DESC",null);

            if(c.moveToFirst()) {
                viewUpdPostId.setText(c.getString(0));
                viewUpdUser.setText(userNickName);
                viewUpdDate.setText(c.getString(2));
                viewUpdTime.setText(c.getString(3));
                viewUpdPost.setText(c.getString(4));
            }
            else {
                showMessage("Issue","Already reviewing the first post");
            }
        }

        // Next post on the list
        if(view == btnUpdNext) {
            // get the next record
            Cursor c = db.rawQuery("Select * from posts where userid ='" +
                    userId + "' and postid > '" + PostIdNum + "'",null);

            if(c.moveToFirst()) {
                viewUpdPostId.setText(c.getString(0));
                viewUpdUser.setText(userNickName);
                viewUpdDate.setText(c.getString(2));
                viewUpdTime.setText(c.getString(3));
                viewUpdPost.setText(c.getString(4));
            }
            else {
                showMessage("Issue","Already viewing the last post");
            }
        }

        // Update the selected post
        if(view == btnUpdatePost) {
            Intent intent = new Intent(this, UpdateThePostActivity.class);
            intent.putExtra("PostID", PostId);
            startActivityForResult(intent, REQUEST_CODE_1);
        }
    }

    // This method is invoked when target activity return result data back.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dataIntent) {
        super.onActivityResult(requestCode, resultCode, dataIntent);

        // The returned result data is identified by requestCode.
        // The request code is specified in startActivityForResult(intent, REQUEST_CODE_1); method.
        switch (requestCode)
        {
            // This request code is set by startActivityForResult(intent, REQUEST_CODE_1) method.
            case REQUEST_CODE_1:
                if(resultCode == RESULT_OK)
                {
                    String PostId = dataIntent.getStringExtra("PostID_return");
                    int PostIdNum = 0;
                    try {
                        PostIdNum = Integer.parseInt(PostId);
                    }
                    catch(NumberFormatException nfe) {
                        showMessage("Error", "Cannot convert post id to number");
                        return;
                    }

                    // update the post
                    Cursor c = db.rawQuery("Select * from posts where postid = '"
                            + PostIdNum + "'",null);

                    if(c.moveToFirst()) {
                        viewUpdDate.setText(c.getString(2));
                        viewUpdTime.setText(c.getString(3));
                        viewUpdPost.setText(c.getString(4));
                    }
                }
        }
    }

    public void showMessage (String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
