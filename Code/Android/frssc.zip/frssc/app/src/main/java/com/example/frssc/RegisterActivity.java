package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    // variables and database connection
    Button btnRegUser;
    EditText edtUserId, edtPassword, edtNickName;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // reference edit fields and buttons
        edtUserId = findViewById(R.id.edtUserId);
        edtPassword = findViewById(R.id.edtPassWord);
        edtNickName = findViewById(R.id.edtNickName);
        btnRegUser = findViewById(R.id.btnRegUser);
        btnRegUser.setOnClickListener(this);

        // setup our database connection
        db=openOrCreateDatabase("FRSSCDB", Context.MODE_PRIVATE,null);
    }

    public void onClick(View view) {

        // check all data is entered or not
        if (edtUserId.getText().toString().trim().length()==0 ||
            edtPassword.getText().toString().trim().length()==0 ||
            edtNickName.getText().toString().trim().length()==0 ) {
            showMessage("Error","All Fields MUST be filled in");
            return;
        }

        // see if we can find that id in our database or not
        Cursor c = db.rawQuery("SELECT * FROM register WHERE userid ='" + edtUserId.getText().toString().trim() + "'", null);

        // if we find anything, then report it as an error
        if (c.moveToFirst()) {
            showMessage("Error","That UserId already exists - try another");
            return;
        }

        // if we get here, then our id does not exist and we can add it in
        db.execSQL("INSERT INTO register VALUES('"+
                edtUserId.getText().toString().trim()+"','"+
                edtPassword.getText().toString().trim()+"','"+
                edtNickName.getText().toString().trim()+"');");

        showMessage("Success","UserID has been successfully registered.");

        // reset our input fields
        edtUserId.setText("");
        edtPassword.setText("");
        edtNickName.setText("");
        edtUserId.requestFocus();

        // stay on the screen
        return;
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
