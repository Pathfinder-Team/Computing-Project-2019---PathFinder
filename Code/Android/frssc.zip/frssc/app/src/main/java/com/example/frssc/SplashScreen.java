package com.example.frssc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        TextView splash = (TextView) findViewById(R.id.splashTop);
        ImageView splash_image = (ImageView) findViewById(R.id.splashImage);
        TextView version = (TextView) findViewById(R.id.splashVersion);

        Animation fade1 = AnimationUtils.loadAnimation(this, R.anim.fade_in1);
        Animation fade2 = AnimationUtils.loadAnimation(this, R.anim.fade_in2);
        Animation fade3 = AnimationUtils.loadAnimation(this, R.anim.fade_in3);

        fade3.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationEnd (Animation animation) {
                Intent intent = new Intent(SplashScreen.this, MainActivity.class);
                startActivity(intent);
            }

            public void onAnimationStart (Animation animation) {
            }

            public void onAnimationRepeat (Animation animation) {
            }
        });

        splash.startAnimation(fade1);
        splash_image.startAnimation(fade2);
        version.startAnimation(fade3);
    }

    public void onPause() {
        super.onPause();

        TextView splash = (TextView) findViewById(R.id.splashTop);
        ImageView splash_image = (ImageView) findViewById(R.id.splashImage);
        TextView version = (TextView) findViewById(R.id.splashVersion);

        splash.clearAnimation();
        splash_image.clearAnimation();
        version.clearAnimation();
    }
}

